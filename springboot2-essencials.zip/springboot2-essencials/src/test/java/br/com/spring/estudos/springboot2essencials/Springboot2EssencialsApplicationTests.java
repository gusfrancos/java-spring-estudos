package br.com.spring.estudos.springboot2essencials;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springboot2EssencialsApplicationTests {

	@Test
	void contextLoads() {
	}

}
